<?php get_header(); ?>
    
    <div class="content">
        <div class="container header-archive">
            <div class="child-header-archive">
            <div class="child-header-archive">
            <div class="title-archive">
                <h1>
                    <!-- GET SEARCH QUERY -->
                    <svg class="search-sm-vc" viewBox="0 0 82.88 47.83">
                        <g>
                            <circle cx="35.75" cy="18.23" r="7.49" />
                            <path d="M0,0V47.83H82.88V0ZM55.54,40.25,42.08,26.79a10.66,10.66,0,1,1,2.23-2.23L57.77,38Z" />
                        </g>
                    </svg> 
                    <br>
                    <?php echo get_search_query(); ?>
                </h1>
            </div>
            </div>
            </div>
        </div>

        <div class="container">    
            <div class="col-m-8">
            <!-- CONTENT -->
            <?php
                echo do_shortcode('[displayingContentPost]');
                if (!have_posts()): ?>
                    <div class="result-search">
                        <svg class="search-vector" viewBox="0 0 362 362">
                            <g>
                                <path
                                    d="M216.32,191.19a120.29,120.29,0,1,0-25.13,25.13L335.87,361,361,335.87Zm-24.15,12-6.93,5.13A109,109,0,0,1,120,229.92a110,110,0,1,1,110-110,109,109,0,0,1-21.64,65.28l-5.13,6.93,143.71,143.7-11,11Z" />
                                <path
                                    d="M120,25.54A94.42,94.42,0,1,0,214.38,120,94.53,94.53,0,0,0,120,25.54Zm0,178.84A84.42,84.42,0,1,1,204.38,120,84.51,84.51,0,0,1,120,204.38Z" />
                            </g>
                        </svg>
                    </div>
                    <div class="no-result">
                        <h1><?php echo get_search_query(); ?></h1> &nbsp; &nbsp;
                        <svg class="cross-vector" viewBox="0 0 69 69">
                            <g>
                                <path
                                    d="M0,0V69H69V0ZM57.83,49.06l-7.77,7.77L34.5,41.27,18.94,56.83l-7.77-7.77L26.73,33.5,11.17,17.94l7.77-7.77L34.5,25.73,50.06,10.17l7.77,7.77L42.27,33.5Z" />
                            </g>
                        </svg>
                    </div>
                    <!-- Form search -->
                    <div class="searching-form">
                        <form method="get" action="<?php echo home_url()?>">
                            <input type="text" class="search-input" name="s"/>
                            <button type="submit" class="searching">
                                <div class="lookup">
                                    <svg viewBox="0 0 21.52 21.61">
                                        <g>
                                            <path d="M13.72,11.69A7.5,7.5,0,1,0,7.5,15a7.38,7.38,0,0,0,4.07-1.21l7.83,7.82,2.12-2.12ZM7.5,3A4.5,4.5,0,1,1,3,7.5,4.51,4.51,0,0,1,7.5,3Z" />
                                        </g>
                                    </svg>
                                </div>
                            </button>
                        </form>
                    </div>
            <?php endif; ?>
            </div>
            <div class="col-m-4">
                <!-- SIDEBAR -->
                <?php get_sidebar('main'); ?>
            </div>
        </div>
    </div>
    
<?php get_footer(); ?>