<div class="extra-footer">
    <div class="container">
        <div class="row">
            <?php get_sidebar( 'fore-footer' ); ?>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="footer">
    <div class="content-footer">
        <p>
            <a href="http://codetmen.com" target="_blank">&copy;2019 | CODETMEN</a>
            <span style="float: right;"><?php echo get_bloginfo('name'); ?></span>
        </p>
    </div>
</footer>

<?php
    wp_footer();
?>
<script lang="javascript">
    const header1 = document.getElementById('header-1');
    const header2 = document.getElementById('header-2');
    const header3 = document.getElementById('header-3');

    // condition for header script execution
    if(header1 != null ){
        jQuery("#carousel").flipster({
            style:'coverflow',
            spacing: -0.5,
            buttons:   true,
            loop: 'false',
            fadeIn: 400,
            start:'center',
            scrollwheel: true,
        });

        // autoplay duration
        jQuery("#carousel").flipster('play', 5000);
    }
    if(header2 != null ){
        jQuery("#flat").flipster({
            style: 'flat',
            spacing: -0.25,
            buttons: true,
            loop: 'false',
            fadeIn: 400,
            start:'center',
        });

        // autoplay duration
        jQuery("#flat").flipster('play', 5000);
    }
    if(header3 != null ){
        jQuery("#wheel").flipster({
            style: 'wheel',
            spacing: 0,
            loop: 'false',
            buttons: true,
            fadeIn: 400,
            start:'center',
            scrollwheel: true,
        });

        // autoplay duration
        jQuery("#wheel").flipster('play', 5000);
    }
</script>
</body>
</html>