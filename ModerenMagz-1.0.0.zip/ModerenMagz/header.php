<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html" charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Codetmen"/>
    <meta name="copyright" content="Codetmen"/>
    
    <?php if(is_front_page()): ?>
        <title><?php echo get_bloginfo(); ?></title>
    <?php elseif(is_page()): ?>
        <title><?php echo get_bloginfo().' - '.get_the_title(); ?></title>
    <?php elseif(is_single()): ?>
        <title><?php echo get_bloginfo().' - '.get_the_title(); ?></title>
    <?php else: ?>
        <title><?php echo get_bloginfo(); ?></title>
    <?php endif; ?>

    <?php 
    //Get the_content from a post or page
    function mm_content(){
        global $post;
        return apply_filters('the_content', get_post_field('post_content', $post->id));
    }
    ?>

    <?php // meta tags ?>
    <?php if(is_front_page()): ?>
        <meta name="title" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta name="description" content="<?php echo get_bloginfo('description'); ?>"/>
        <meta name="keywords" content="<?php echo get_bloginfo('name').' - '.get_bloginfo('description'); ?>"/>
    <?php elseif(is_page()): ?>
        <meta name="title" content="<?php echo get_bloginfo('name').' - '.get_the_title(); ?>"/>
        <meta name="description" content="<?php echo wp_trim_words( mm_content(), 30 ); ?>"/>
        <meta name="keywords" content="<?php echo get_bloginfo('name').' - '.get_the_title(); ?>"/>
    <?php elseif(is_single()): ?>
        <meta name="title" content="<?php echo get_bloginfo('name').' - '.get_the_title(); ?>"/>
        <meta name="description" content="<?php echo wp_trim_words( mm_content(), 30 ); ?>"/>
        <meta name="keywords" content="<?php echo get_post_meta( $post->ID, 'content-keywords', true ); ?>"/>
    <?php else: ?>
        <meta name="title" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta name="description" content="<?php echo get_bloginfo('description'); ?>"/>
        <meta name="keywords" content="<?php echo get_bloginfo('name').' - '.get_bloginfo('description'); ?>"/>
    <?php endif; ?>

    <!-- Open Graph meta tags for social media -->
    <?php if(is_front_page()): ?>
        <meta property="og:title" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta property="og:description" content="<?php echo get_bloginfo('description'); ?>"/>
        <meta property="og:site_name" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta property="og:image" content="<?php echo get_site_icon_url(); ?>"/>
        <meta property="og:type" content="blog"/>
        <meta property="og:url" content="<?php echo esc_url( home_url( '/' ) ); ?>"/>
    <?php elseif(is_page()): ?>
        <meta property="og:title" content="<?php echo get_bloginfo('name').' - '.get_the_title(); ?>"/>
        <meta property="og:description" content="<?php echo wp_trim_words( mm_content(), 30 ); ?>"/>
        <meta property="og:site_name" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta property="og:image" content="<?php echo get_the_post_thumbnail_url(); ?>"/>
        <meta property="og:type" content="blog"/>
        <meta property="og:url" content="<?php echo get_the_permalink(); ?>"/>
    <?php elseif(is_single()): ?>
        <meta property="og:title" content="<?php echo get_bloginfo('name').' - '.get_the_title(); ?>"/>
        <meta property="og:description" content="<?php echo wp_trim_words( mm_content(), 30 ); ?>"/>
        <meta property="og:site_name" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta property="og:image" content="<?php echo get_the_post_thumbnail_url(); ?>"/>
        <meta property="og:type" content="blog"/>
        <meta property="og:url" content="<?php echo get_the_permalink(); ?>"/>
    <?php else: ?>
        <meta property="og:title" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta property="og:description" content="<?php echo get_bloginfo('description'); ?>"/>
        <meta property="og:site_name" content="<?php echo get_bloginfo('name'); ?>"/>
        <meta property="og:image" content="<?php echo get_site_icon_url(); ?>"/>
        <meta property="og:type" content="blog"/>
        <meta property="og:url" content="<?php echo esc_url( home_url( '/' ) ); ?>"/>
    <?php endif; ?>
    

    <link rel="chanonical" href="<?php echo esc_url(home_url('/')); ?>"/>
    <link rel="shortlink" href="<?php echo esc_url(home_url('/')); ?>"/>

    <meta name="MobileOptimized" content="width"/>
    <meta name="HandheldFriendly" content="true"/>

    <?php
        wp_head();
    ?>
</head>

<body>
<!-- Displaying Navigation -->
<?php
    print do_shortcode( '[displayingNav]' );
?>