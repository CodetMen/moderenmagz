<?php get_header(); ?>

<div class="content">
    <!-- Header -->
    <?php
        echo do_shortcode( '[displayingHeader]' );
    ?>

    <div class="container">    
        <div class="col-m-8">
            <!-- CONTENT -->
            <?php
                print do_shortcode( '[displayingContent]' );
            ?>
            <a href="<?php echo site_url('/blog'); ?>" class="more-link">
            More >>
            </a>
        </div>
        <div class="col-m-4">
            <!-- SIDEBAR -->
            <?php get_sidebar('main'); ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>