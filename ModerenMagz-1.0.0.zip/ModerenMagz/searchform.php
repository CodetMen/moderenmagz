<div class="search-sidebar">
    <form method="get" action="<?php echo home_url()?>">
        <input type="text" class="search-input" name="s" value="<?php echo get_search_query(); ?>"/>
        <button type="submit" class="search-btn">
            <div class="lookup">
                <svg viewBox="0 0 21.52 21.61">
                    <g>
                        <path d="M13.72,11.69A7.5,7.5,0,1,0,7.5,15a7.38,7.38,0,0,0,4.07-1.21l7.83,7.82,2.12-2.12ZM7.5,3A4.5,4.5,0,1,1,3,7.5,4.51,4.51,0,0,1,7.5,3Z" />
                    </g>
                </svg>
            </div>
        </button>
    </form>
</div>