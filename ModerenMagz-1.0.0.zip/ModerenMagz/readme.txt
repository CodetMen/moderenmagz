=== ModerenMagz ===

Contributors:codetmen
Tags: three-columns, right-sidebar, foot-sidebar, full-width-template, custom-background, custom-colors, custom-menu, featured-images, theme-options, threaded-comments, blog, keywords, seo, responsive, custom-fonts
Requires at least: 4.9
Tested up to: 5.2.2
Stable tag: 1.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


#### Description ####
ModerenMagz is a stunning, professional and flexible WordPress Theme. It is an impressive WordPress theme for a professional blogger, photographer, newspaper, or other activities you need to post within professional. he layout of the theme has been well-organized and designed with supreme quality. With a unique widget available in the theme, users can play with them and design it beautifully. 

== License ==
ModerenMagz WordPress Theme, Copyright (C) 2019, Codetmen
ModerenMagz is distributed under the terms of the GPL GNU General Public License v3 or later


#### Installation ####
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


#### Changelog ####

==2019/11/12== v-1.0.0
*initial


#### Credits ####
* Google Fonts https://fonts.google.com/ 
* Jquery https://jquery.org/license/
* Flipster https://github.com/drien/jquery-flipster Copyright (c) 2013-2019 Adrien Delessert


#### Theme Feature ####

 * Have Home page setting on customizer for each section whether users can edit each section.
 * Have color editor theme on customizer color theme
 * Have font editor theme on customizer for font theme
 * Have design layout on customizer for sidebar.
 * Have Copyright field on customizer for footer.


#### Credits ####
Image used in screenshot, dummy and video
* https://pixabay.com/photos/laptop-computer-browser-research-2562325/ - License CC0 Public Domain
* https://pixabay.com/photos/man-work-desk-business-person-597178/ - License CC0 Public Domain
* https://pixabay.com/photos/beard-brainstorming-business-2286440/ - License CC0 Public Domain
* https://pixabay.com/photos/people-girl-beauty-face-eyebrow-2605526/ - License CC0 Public Domain
* https://pixabay.com/photos/girl-people-tenderness-woman-657753/ - License CC0 Public Domain
* https://pixabay.com/photos/startup-whiteboard-room-indoors-3267505/- License CC0 Public Domain
* https://pixabay.com/photos/startup-whiteboard-room-indoors-3267505/- License CC0 Public Domain