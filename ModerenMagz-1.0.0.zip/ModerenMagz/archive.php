<?php get_header(); ?>

<div class="content">
    
    <div class="container header-archive">
        <div class="child-header-archive">
        <div class="child-header-archive">
        <div class="title-archive">
            <h1>
                <?php echo the_archive_title(); ?>
            </h1>
        </div>
        </div>
        </div>
    </div>

    <div class="container">    
        <div class="col-m-8">
            <!-- CONTENT -->
            <?php
                echo do_shortcode('[displayingContentPost]');
            ?>
        </div>
        <div class="col-m-4">
            <!-- SIDEBAR -->
            <?php get_sidebar('main'); ?>
        </div>
    </div>
</div>    

<?php get_footer(); ?>