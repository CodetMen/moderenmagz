<?php
class ModerenMagz { 
    
    // funtion listing font from google fonts
    function listGF($url_api){
        // suppress the warning by putting an error control operator (i.e. @) in front of the call to file_get_contents()
        $data = json_decode(@file_get_contents($url_api), true);

        if($data != null):
            $listGoogleFonts = array(""=>"default");
            
            foreach($data['items'] as $datum):
                foreach($datum['files'] as $specFont => $linkFont):
                    $value = $datum['family'];
                    $key = 
                    $listGoogleFonts[$key] = $value;
                endforeach;
            endforeach;

            return $listGoogleFonts;
        else:
            echo '<div style="width:100%; height:auto; background-color:red; color:white; text-align:center;" >';
            echo 'Please check your internet connection to get font from google font';
            echo '</div>';
        endif;
    }

    // Displaying breadcrumb in page.php
    function the_breadcrumb() {
        if(!is_home()):  
            echo '<a href="';
            echo get_option('Home');
            echo '">';
            bloginfo('name');
            echo "</a> &raquo; ";
            if (is_category() || is_single()):
                the_category(', ');
                if (is_single()):
                    echo " &raquo; ";
                    the_title();
                endif;
            elseif(is_page()):
                echo the_title();
            endif;
        elseif(is_home()):
            bloginfo('name');
        endif;
    }
}
?>