<?php
// Register and load the widget
function widget_load_profil() {
    register_widget( 'widget_profil' );
}
add_action( 'widgets_init', 'widget_load_profil' );

// Widget Profil
require get_template_directory().'/inc/widget/widget-profil.php';
?>