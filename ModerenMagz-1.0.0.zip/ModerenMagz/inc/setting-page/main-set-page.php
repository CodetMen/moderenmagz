<?php 
    // Submit page settings
    if(array_key_exists('navbar-setting', $_POST)):
        update_option( 'mm_nav', $_POST['nav']);
    elseif(array_key_exists('header-setting', $_POST)):  
        update_option( 'mm_header', $_POST['header']);
    elseif(array_key_exists('post-setting', $_POST)):   
        update_option( 'mm_content', $_POST['content']);
    endif;
    
    // get submit value and set default
    $inp_nav = get_option( 'mm_nav', 'nav-1' );
    $inp_header = get_option( 'mm_header', 'header-1' );
    $inp_content = get_option( 'mm_content', 'content-1' );
?>

<h1>ModerenMagz Settings</h1>

<div class="tab">
    <button class="tablinks" onclick="openMenus(event, 'NavSetting')">Navbar Setting</button>
    <button class="tablinks" onclick="openMenus(event, 'HeaderSetting')">Header Setting</button>
    <button class="tablinks" onclick="openMenus(event, 'PostSetting')">Post Setting</button>
</div>

<div id="front-setting">
    <h1>Setting ModerenMagz Theme</h1>
</div>

<div id="NavSetting" class="tabcontent">
    <form action="" method="post">
        <h3>Navibar Setting</h3>
        <label class="container">
            <?php if($inp_nav === 'nav-1'):
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/nav_1.png"/>';
                print '<input type="radio" checked="checked" name="nav" value="nav-1">';
                print '<p>Style navigation 1</p>';
            else:
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/nav_1.png"/>';
                print '<input type="radio" name="nav" value="nav-1">';
                print '<p>Style navigation 1</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>
        <label class="container">
            <?php if($inp_nav === 'nav-2'):
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/nav_2.png"/>';
                print '<input type="radio" checked="checked" name="nav" value="nav-2">';
                print '<p>Style navigation 2</p>';
            else:
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/nav_2.png"/>';
                print '<input type="radio" name="nav" value="nav-2">';
                print '<p>Style navigation 2</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>
        <label class="container">
            <?php if($inp_nav === 'nav-3'):
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/nav_3.png"/>';
                print '<input type="radio" checked="checked" name="nav" value="nav-3">';
                print '<p>Style navigation 3</p>';
            else:
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/nav_3.png"/>';
                print '<input type="radio" name="nav" value="nav-3">';
                print '<p>Style navigation 3</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>

        <button type="submit" name="navbar-setting">Save Settings</button>
    </form>
</div>

<div id="HeaderSetting" class="tabcontent">
    <form action="" method="post">
        <h3>Header Setting</h3>
        <label class="container">
            <?php if($inp_header === 'header-1'):
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/header_1.png"/>';
                print '<input type="radio" checked="checked" name="header" value="header-1">';
                print '<p>Style Header 1</p>';
            else:
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/header_1.png"/>';
                print '<input type="radio" name="header" value="header-1">';
                print '<p>Style Header 1</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>
        <label class="container">
            <?php if($inp_header === 'header-2'):
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/header_2.png"/>';
                print '<input type="radio" checked="checked" name="header" value="header-2">';
                print '<p>Style Header 2</p>';
            else:
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/header_2.png"/>';
                print '<input type="radio" name="header" value="header-2">';
                print '<p>Style Header 2</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>
        <label class="container">
            <?php if($inp_header === 'header-3'):
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/header_3.png"/>';
                print '<input type="radio" checked="checked" name="header" value="header-3">';
                print '<p>Style Header 3</p>';
            else:
                print '<img width="60%" height="auto" src="'.get_template_directory_uri().'/img/component/header_3.png"/>';
                print '<input type="radio" name="header" value="header-3">';
                print '<p>Style Header 3</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>

        <button type="submit" name="header-setting">Save Settings</button>
    </form>
</div>

<div id="PostSetting" class="tabcontent">
    <form action="" method="post">
        <h3>Post Setting</h3>
        <label class="container">
            <?php if($inp_content === 'content-1'):
                print '<img width="20%" height="auto" src="'.get_template_directory_uri().'/img/component/post_1.png"/>';
                print '<input type="radio" checked="checked" name="content" value="content-1">';
                print '<p>Style Post 1</p>';
            else:
                print '<img width="20%" height="auto" src="'.get_template_directory_uri().'/img/component/post_1.png"/>';
                print '<input type="radio" name="content" value="content-1">';
                print '<p>Style Post 1</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>
        <label class="container">
            <?php if($inp_content === 'content-2'):
                print '<img width="40%" height="auto" src="'.get_template_directory_uri().'/img/component/post_2.png"/>';
                print '<input type="radio" checked="checked" name="content" value="content-2">';
                print '<p>Style Post 2</p>';
            else:
                print '<img width="40%" height="auto" src="'.get_template_directory_uri().'/img/component/post_2.png"/>';
                print '<input type="radio" name="content" value="content-2">';
                print '<p>Style Post 2</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>
        <label class="container">
            <?php if($inp_content === 'content-3'):
                print '<img width="20%" height="auto" src="'.get_template_directory_uri().'/img/component/post_3.png"/>';
                print '<input type="radio" checked="checked" name="content" value="content-3">';
                print '<p>Style Post 3</p>';
            else:
                print '<img width="20%" height="auto" src="'.get_template_directory_uri().'/img/component/post_3.png"/>';
                print '<input type="radio" name="content" value="content-3">';
                print '<p>Style Post 3</p>';
            endif; ?>
            <span class="checkmark"></span>
        </label>

        <button type="submit" name="post-setting">Save Settings</button>
    </form>
</div>