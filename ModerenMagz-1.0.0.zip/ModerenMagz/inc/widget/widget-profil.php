<?php
// Creating the widget 
class widget_profil extends WP_Widget {
 
    function __construct(){
        // Add Widget scripts
        add_action('admin_enqueue_scripts', array($this, 'script_widget'));

        parent::__construct(
            'widget_profil', // Base ID
            __( 'ModerenMagz Profil', 'moderenmagz' ), // Name
            array( 'description' => __( 'Displaying profil', 'moderenmagz' ), ) // Args
        );
    }

    // Call media upload using script
    public function script_widget(){
        wp_enqueue_script( 'media-upload' );
        wp_enqueue_media();
        wp_enqueue_script('widget-script', get_theme_file_uri('/inc/widget/widget-script.js'), array('jquery'));
    }
    
    // Creating widget front-end / Displaying
    public function widget( $args, $instance ){
        // Our variables from the widget settings
        $title = apply_filters( 'widget_title', empty( $instance['title'] ) ? __( 'Title', 'moderenmagz' ) : $instance['title'] );
        $image = !empty( $instance['imgprofil'] ) ? $instance['imgprofil'] : '';
        $text = !empty( $instance['txtprofil'] ) ? $instance['txtprofil'] : '';

        ob_start();
        echo $args['before_widget'];
            if ( ! empty( $instance['title'] ) ) {
                echo $args['before_title'] . $title . $args['after_title'];
            }
            ?>

            <?php if($image): ?>
                <div class="profil-style">
                    <div class="img-profil">
                        <img src="<?php echo esc_url($image); ?>" alt="">
                    </div>
                    <p class="txt-profil">
                        <?php echo $text; ?>
                    </p>
                </div>
            <?php endif; ?>

            <?php
        echo $args['after_widget'];
        ob_end_flush();
    }
            
    // Widget Backend / Form 
    public function form( $instance ) {
        $title = !empty($instance['title']) ? $instance['title'] : __( '', 'moderenmagz' );
        $image = !empty($instance['imgprofil']) ? $instance['imgprofil'] : '';
        $text = !empty($instance['txtprofil']) ? $instance['txtprofil'] : __('', 'moderenmagz');
        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'imgprofil' ); ?>"><?php _e( 'Image [1:1]:' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'imgprofil' ); ?>" name="<?php echo $this->get_field_name( 'imgprofil' ); ?>" type="text" value="<?php echo esc_url( $image ); ?>" />
            <button class="upload_image_button button button-primary">Upload Image</button>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'txtprofil' ); ?>"><?php _e( 'Text:' ); ?></label>
            <textarea class="widefat" id="<?php echo $this->get_field_id( 'txtprofil' ); ?>" name="<?php echo $this->get_field_name( 'txtprofil' ); ?>" type="text"><?php echo esc_attr( $text ); ?></textarea>
        </p>
        <?php
    }
        
    // Updating widget replacing old instances with new
    public function update( $new_instance, $old_instance ){
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['imgprofil'] = ( ! empty( $new_instance['imgprofil'] ) ) ? $new_instance['imgprofil'] : '';
        $instance['txtprofil'] = ( ! empty( $new_instance['txtprofil'] ) ) ? strip_tags( $new_instance['txtprofil'] ) : '';

        return $instance;
    }
}
?>