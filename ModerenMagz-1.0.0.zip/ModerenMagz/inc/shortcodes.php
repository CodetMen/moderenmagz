<?php
// #### SHORTCODE
// Display nav
function displaying_nav(){
    $inp_nav = get_option( 'mm_nav', 'nav-1' );
    if($inp_nav == 'nav-3'):
        require get_template_directory().'/template-parts/nav-3.php';
    elseif($inp_nav == 'nav-2'):
        require get_template_directory().'/template-parts/nav-2.php';
    else:
        require get_template_directory().'/template-parts/nav-1.php';
    endif;
}
add_shortcode( 'displayingNav', 'displaying_nav' );

// Displaying header
function displaying_header(){
    $inp_header = get_option( 'mm_header', 'header-1' );
    if($inp_header == 'header-3'):
        require get_template_directory().'/template-parts/header-3.php';
    elseif($inp_header == 'header-2'):
        require get_template_directory().'/template-parts/header-2.php';
    else:
        require get_template_directory().'/template-parts/header-1.php';
    endif;
}
add_shortcode( 'displayingHeader', 'displaying_header' );

// Displaying post for front page
function displaying_content(){
    $inp_content = get_option( 'mm_content', 'content-1' );
    if($inp_content == 'content-3'):
        require get_template_directory().'/template-parts/content-3.php';
    elseif($inp_content == 'content-2'):
        require get_template_directory().'/template-parts/content-2.php';
    else:
        require get_template_directory().'/template-parts/content-1.php';
    endif;
}
add_shortcode( 'displayingContent', 'displaying_content' );

// Displaying post for other pages
function displaying_content_post(){
    $inp_content = get_option( 'mm_content', 'content-1' );
    if($inp_content == 'content-3'):
        require get_template_directory().'/template-parts/list-post-3.php';
    elseif($inp_content == 'content-2'):
        require get_template_directory().'/template-parts/list-post-2.php';
    else:
        require get_template_directory().'/template-parts/list-post-1.php';
    endif;
}
add_shortcode( 'displayingContentPost', 'displaying_content_post' );

// Displaying image 404
function displaying_img_404(){
    $img_404 = get_option( 'def_404_img', 'default-404' );
    if($img_404 == 'default-404'):
        echo 'Success default image';
    elseif($img_404 == 'user-404'):
        echo 'Success user image';
    endif;
}
add_shortcode( 'displayingImg404', 'displaying_img_404' );
?>