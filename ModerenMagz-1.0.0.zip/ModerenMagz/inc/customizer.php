<?php

function moderenmagz_customize_register( $wp_customize ) {
	
	// customized color style
	require get_template_directory().'/inc/customize/customize-color-style.php';
	
	// customized font style
	require get_template_directory().'/inc/customize/customize-font-style.php';

}
add_action( 'customize_register', 'moderenmagz_customize_register' );


function moderenmagz_customize_css()
{
	// head color style
	require get_template_directory().'/inc/customize/head-color-style.php';
	
	// head font style
	require get_template_directory().'/inc/customize/head-font-style.php';
}
add_action( 'wp_head', 'moderenmagz_customize_css');

?>