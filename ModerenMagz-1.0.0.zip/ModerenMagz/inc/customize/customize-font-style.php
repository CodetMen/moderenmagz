<?php
    require get_template_directory().'/inc/ModerenMagz.php';

    /* Font customizer ===================================== */
    $wp_customize->add_section( 'mm_section_font' , array(
        'title'      => __( 'G Font Style', 'moderenmagz' ),
        'priority'   => 40,
    ));

    $url_gf = 'https://www.googleapis.com/webfonts/v1/webfonts?key=AIzaSyD4pE96n9lcnFf-9kTXlB9By8VQjIvQjQY';
    // object google font
    $obj_gf = new ModerenMagz();
    $listingFonts = $obj_gf->listGF($url_gf);

    // Font header 
    $wp_customize->add_setting( 'mm_setting_font_header' , array(
        'default'        => 'Open Sans',
        'capability'     => 'edit_theme_options',
    ));

    $wp_customize->add_control( 'font_header', array(
        'label'      => __( 'Font Header:', 'moderenmagz' ),
        'section'    => 'mm_section_font',
        'settings'   => 'mm_setting_font_header',
        'type'       => 'select',
        'choices'    => $listingFonts,
    ));

    // Font footer 
    $wp_customize->add_setting( 'mm_setting_font_footer' , array(
        'default'        => 'Open Sans',
        'capability'     => 'edit_theme_options',
    ));

    $wp_customize->add_control( 'font_footer', array(
        'label'      => __( 'Font Footer:', 'moderenmagz' ),
        'section'    => 'mm_section_font',
        'settings'   => 'mm_setting_font_footer',
        'type'       => 'select',
        'choices'    => $listingFonts,
    ));

    // Font title widget 
    $wp_customize->add_setting( 'mm_setting_font_title_widget' , array(
        'default'        => 'Open Sans',
        'capability'     => 'edit_theme_options',
    ));

    $wp_customize->add_control( 'font_title_widget', array(
        'label'      => __( 'Font Title Widget:', 'moderenmagz' ),
        'section'    => 'mm_section_font',
        'settings'   => 'mm_setting_font_title_widget',
        'type'       => 'select',
        'choices'    => $listingFonts,
    ));

    // Font navbar
    $wp_customize->add_setting( 'mm_setting_font_navbar' , array(
        'default'        => 'Open Sans',
        'capability'     => 'edit_theme_options',
    ));

    $wp_customize->add_control( 'font_navbar', array(
        'label'      => __( 'Font Navbar:', 'moderenmagz' ),
        'section'    => 'mm_section_font',
        'settings'   => 'mm_setting_font_navbar',
        'type'       => 'select',
        'choices'    => $listingFonts,
    ));

    // Font title
    $wp_customize->add_setting( 'mm_setting_font_title' , array(
        'default'        => 'Open Sans',
        'capability'     => 'edit_theme_options',
    ));

    $wp_customize->add_control( 'font_title', array(
        'label'      => __( 'Font Title:', 'moderenmagz' ),
        'section'    => 'mm_section_font',
        'settings'   => 'mm_setting_font_title',
        'type'       => 'select',
        'choices'    => $listingFonts,
    ));

    // Font paragraph
    $wp_customize->add_setting( 'mm_setting_font_paragraph' , array(
        'default'        => 'Open Sans',
        'capability'     => 'edit_theme_options',
    ));

    $wp_customize->add_control( 'font_paragraph', array(
        'label'      => __( 'Font Paragraph:', 'moderenmagz' ),
        'section'    => 'mm_section_font',
        'settings'   => 'mm_setting_font_paragraph',
        'type'       => 'select',
        'choices'    => $listingFonts,
    ));
    /* Font customizer ===================================== */
?>