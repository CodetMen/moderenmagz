<style type="text/css">
    body { 
        background-color: <?php echo get_theme_mod('mm_setting_bg_color', '#fff4f9'); ?>;
    }

    .listing, .extra-footer, .footer, .thumbnail, .widget > h3, .nav-inherit, .single-img, .header-archive,
    .box-img-lf-top, .box-img-lf-btm, .box-img-rg-top, .box-img-rg-btm, .child-header-archive,
    .profil-style, #menu-menu .sub-menu, .single-content { 
        background-color: <?php echo get_theme_mod('mm_setting_bg_secondary', '#ffffff'); ?>;
    }

    .child-header-archive, .nav-inherit, .comment-single { 
        border-color: <?php echo get_theme_mod('mm_setting_bg_color', '#fff4f9'); ?>;
    }

    .lookup {
        fill: <?php echo get_theme_mod('mm_setting_txt_secondary', '#ffffff'); ?>;
    }

    .lookup:hover {
        fill: <?php echo get_theme_mod('mm_setting_bg_color', '#fff4f9'); ?>;
    }

    .p-caption, .p-tag ul li a, .search-btn, .pagination .current, .searching-form form button, #slideout-menu { 
        background-color: <?php echo get_theme_mod('mm_setting_bg_third', '#000000'); ?>;
    }

    .search-btn, .search-sidebar .search-input, .searching-form form button, .searching-form form input {
        border-color: <?php echo get_theme_mod('mm_setting_bg_third', '#000000'); ?>
    }

    .error-page .error-vector, .result-search .search-vector, .cross-vector, .search-sm-vc {
        fill: <?php echo get_theme_mod('mm_setting_bg_third', '#000000'); ?>
    }

    .comment-form input[type=submit] {
        background-color: <?php echo get_theme_mod('mm_setting_txt_primary', '#000000'); ?>;
    }

    .widget_pages a, .widget_categories a, .single-tags li, .cat-item a, #menu-menu .sub-menu, .widget input,
    .comments-area .comment-body, .comment-form input, select, textarea, .comment-form input[type=submit] { 
        border-color: <?php echo get_theme_mod('mm_setting_txt_primary', '#000000'); ?>;
    }

    #foot_sidebar {
        border-bottom-color: <?php echo get_theme_mod('mm_setting_txt_primary', '#000000'); ?>;
    }

    .p-detail p, .p-detail h3, .foot-widget, .widget, .foot-widget a, .widget a, .p-author,
    .content-footer, .read-link, .single-title h1, .single-detail p, .single-tags a,
    .comment-form label, .comment-form h2, .page-title h1, .txt-profil, .more-link, .pagination a,
    .title-archive h1, #menu-menu li a, .content-footer a, .comment-body a, .comments-area,
    .no-result, .single-detail, .detail-post, .nav-inherit, .nav-inherit a, .search-input,
    #comment, .comment-form input[type=submit]:hover { 
        color: <?php echo get_theme_mod('mm_setting_txt_primary', '#000000'); ?>;
    }

    .comment-form input[type=submit] {
        color: <?php echo get_theme_mod('mm_setting_bg_color', '#fff4f9'); ?>;
    }
    
    .cal-vector, .man-vector {
        fill: <?php echo get_theme_mod('mm_setting_txt_primary', '#000000'); ?>;
    }

    #menu-menu li a:hover {
        color: <?php echo get_theme_mod('mm_setting_bg_color', '#fff4f9'); ?>;
        background-color: <?php echo get_theme_mod('mm_setting_bg_third', '#000000'); ?>;
    }

    .p-caption, .p-tag ul li a, .pagination .current, #slideout-menu {
        color: <?php echo get_theme_mod('mm_setting_txt_secondary', '#ffffff'); ?>;
    }

    .main-title-link { 
        color: <?php echo get_theme_mod('mm_setting_txt_header', '#000000'); ?>;
    }

    .icon-menu { 
        fill: <?php echo get_theme_mod('mm_setting_txt_header', '#000000'); ?>;
    }
</style>