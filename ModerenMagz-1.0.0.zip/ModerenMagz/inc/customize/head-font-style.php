<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo get_theme_mod('mm_setting_font_header', 'Open Sans'); ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo get_theme_mod('mm_setting_font_footer', 'Open Sans'); ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo get_theme_mod('mm_setting_font_title_widget', 'Open Sans'); ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo get_theme_mod('mm_setting_font_navbar', 'Open Sans'); ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo get_theme_mod('mm_setting_font_title', 'Open Sans'); ?>"> 
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=<?php echo get_theme_mod('mm_setting_font_paragraph', 'Open Sans'); ?>">

<!-- DONT FORGET TO CHANGE DEFAULT FONT FOR get_theme_mod TO OPEN SANS  -->

<style type="text/css">
    .main-title, .main-title2, .main-title3 {   
        font-family: <?php echo get_theme_mod('mm_setting_font_header', 'Open Sans'); ?>; 
        font-weight: 700;
    }
    
    .content-footer { 
        font-family: <?php echo get_theme_mod('mm_setting_font_footer', 'Open Sans'); ?>;
    }
    
    .widget h3, .foot-widget h3, .title-archive h1, .comment-form h2, .comment-form label, 
    .comment-form input[type=submit] { 
        font-family: <?php echo get_theme_mod('mm_setting_font_title_widget', 'Open Sans'); ?>;
        font-weight: 700; 
        letter-spacing: 1px;
    }
    
    .navbar ul { 
        font-family: <?php echo get_theme_mod('mm_setting_font_navbar', 'Open Sans'); ?>;
    }
    
    .p-detail h3, .single-title, .page-title, .flipster h3, .overlay-detail h3, .p-author { 
        font-family: <?php echo get_theme_mod('mm_setting_font_title', 'Open Sans'); ?>;
    }
    
    .p-detail p, .widget li, .foot-widget li, .single-detail, .nav-inherit, .overlay-detail p,
    .read-link, .post-categories, .txt-profil, .search-input, .comment-form input, select, textarea, 
    .comments-area, .no-result { 
         font-family: <?php echo get_theme_mod('mm_setting_font_paragraph', 'Open Sans'); ?>;
    }
</style>