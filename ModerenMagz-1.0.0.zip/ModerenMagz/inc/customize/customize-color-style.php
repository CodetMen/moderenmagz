<?php
    /* Color customizer ===================================== */
    $wp_customize->add_section( 'mm_section_color' , array(
        'title'      => __( 'Color Style', 'moderenmagz' ),
        'priority'   => 30,
    ));

    // Color for background theme
    $wp_customize->add_setting( 'mm_setting_bg_color' , array(
        'default'     => '#fff4f9',
        'transport'   => 'refresh',
    ));

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bg_color', array(
        'label'      => __( 'Background Color', 'moderenmagz' ),
        'section'    => 'mm_section_color',
        'settings'   => 'mm_setting_bg_color',
    )));

    // Color for background secondary theme
    $wp_customize->add_setting( 'mm_setting_bg_secondary' , array(
        'default'     => '#ffffff',
        'transport'   => 'refresh',
    ));

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bg_secondary', array(
        'label'      => __( 'Secondary Color', 'moderenmagz' ),
        'section'    => 'mm_section_color',
        'settings'   => 'mm_setting_bg_secondary',
    )));

    // Color for background third theme
    $wp_customize->add_setting( 'mm_setting_bg_third' , array(
        'default'     => '#000000',
        'transport'   => 'refresh',
    ));

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'bg_third', array(
        'label'      => __( 'Third Color', 'moderenmagz' ),
        'section'    => 'mm_section_color',
        'settings'   => 'mm_setting_bg_third',
    )));

    // Color for header text
    $wp_customize->add_setting( 'mm_setting_txt_header' , array(
        'default'     => '#000000',
        'transport'   => 'refresh',
    ));

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'txt_header', array(
        'label'      => __( 'Text header color', 'moderenmagz' ),
        'section'    => 'mm_section_color',
        'settings'   => 'mm_setting_txt_header',
    )));

    // Color for primary text
    $wp_customize->add_setting( 'mm_setting_txt_primary' , array(
        'default'     => '#000000',
        'transport'   => 'refresh',
    ));

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'txt_primary', array(
        'label'      => __( 'Text primary color', 'moderenmagz' ),
        'section'    => 'mm_section_color',
        'settings'   => 'mm_setting_txt_primary',
    )));
    
    // Color for secondary text
    $wp_customize->add_setting( 'mm_setting_txt_secondary' , array(
        'default'     => '#ffffff',
        'transport'   => 'refresh',
    ));

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'txt_secondary', array(
        'label'      => __( 'Text secondary color', 'moderenmagz' ),
        'section'    => 'mm_section_color',
        'settings'   => 'mm_setting_txt_secondary',
    )));
    /* Color customizer ===================================== */
?>