<?php
    // this metabox keywords for post will be displaying in right bar 'side'
    function mm_create_custom_keywords( $post_type, $post ) {
      add_meta_box( 'custom-keywords', __( 'Custom Keywords', 'mm-custom-keywords' ), 'mm_custom_keywords', 'post', 'side', 'high' );
    }
    add_action( 'add_meta_boxes', 'mm_create_custom_keywords', 10, 2 );

    /**
     *  Custom Meta Box content
     */
    function mm_custom_keywords($post){
        ?>
        <label for="metabox-keywords">Ex Keywords: best, blog, one,</label>
        <textarea class="widefat" name="mm-custom-keywords">
            <?php echo get_post_meta( $post->ID, 'content-keywords', true ); ?>
        </textarea>
        <?php
    }
  
    /**
     *  Save textbox content
     */
    function mm_save_custom_keywords($post_id) {
        $textbox_keywords = $_POST['mm-custom-keywords'];
    
        // update/save data with name 'content-keywords'
        update_post_meta( $post_id, 'content-keywords', $textbox_keywords );
    }
    add_action( 'save_post', 'mm_save_custom_keywords' );
?>