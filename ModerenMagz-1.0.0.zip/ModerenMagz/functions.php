<?php 
// Add CSS and JS files
function mm_setup(){
    wp_enqueue_style( 'style', get_stylesheet_uri(), NULL, '1.0.0');
    wp_enqueue_style( 'flipster-css', get_theme_file_uri( '/src/css/jquery.flipster.min.css' ), NULL, '1.0.0');

    wp_enqueue_script( 'jquery', get_theme_file_uri( '/src/js/jquery-3.4.1.min.js' ), NULL, '1.0.0', true);
    wp_enqueue_script( 'main', get_theme_file_uri( '/src/js/main.js' ), array( 'jquery' ), '1.0.0', true);
    wp_enqueue_script( 'jquery-flipster', get_theme_file_uri( '/src/js/jquery.flipster.min.js' ), NULL, '1.0.0', true);
}
add_action( 'wp_enqueue_scripts', 'mm_setup');

// Registers theme support
function mm_init() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');

    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu', 'codetmen' ),
        )
    );

    add_theme_support( 'html5', 
        array('comment-list', 'comment-form', 'search-form')
    );
}
add_action('after_setup_theme', 'mm_init');

//Change Posts labels in sidebar admin menu
function custom_post_menu_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = 'Blog';
    $submenu['edit.php'][5][0] = 'Blog';
    $submenu['edit.php'][10][0] = 'Add Blog';         
}
add_action( 'admin_menu', 'custom_post_menu_label' );

//Change Post labels in admin area
function custom_post_object_label() {
    global $wp_post_types;
    $labels = &$wp_post_types['post']->labels;
    $labels->name = 'Blog';
    $labels->singular_name = 'Blog';
    $labels->add_new = 'Add Blog';
    $labels->add_new_item = 'Add Blog';
    $labels->edit_item = 'Edit Blog';
    $labels->new_item = 'Blog';
    $labels->view_item = 'View Blog';
    $labels->search_items = 'Search Blog';
    $labels->not_found = 'No results on Blog';
    $labels->not_found_in_trash = 'No News in Blog';
    $labels->name_admin_bar = 'Add Blog';
    $labels->featured_image = 'Blog Image [16:9]';
}
add_action( 'init', 'custom_post_object_label' );

//Change page labels in admin area
function custom_page_object_label() {
    global $wp_post_types;
    $labels = &$wp_post_types['page']->labels;
    $labels->featured_image = 'Page Image [16:9]';
}
add_action( 'init', 'custom_page_object_label' );

//  main sidebar
function mm_main_widgets(){
    register_sidebar( 
        array(
            'name' => 'Main Sidebar',
            'id' => 'main_sidebar',
            'before_title' => '<h3>',
            'after_title' => '</h3>',
        )
    );
}
add_action( 'widgets_init', 'mm_main_widgets' );

//  foot sidebar
function mm_foot_widgets(){
    register_sidebar( 
        array(
            'name' => 'Footer Sidebar',
            'id' => 'foot_sidebar',
            'before_widget' => '<li id="foot_sidebar" class="foot-widget col-m-4 col-xs-12">',
            'after_widget' => '</li>',
            'before_title' => '<h3>',
            'after_title' => '</h3>',
        )
    );
}
add_action( 'widgets_init', 'mm_foot_widgets' );


/** ### ModerenMagz Settings ### 
 #################################### **/
function mm_setting_menu(){
    add_menu_page( 'ModerenMagz settings', 'ModerenMagz', 'manage_options', 'mm-setting-menu', 'mm_setting_block', 'dashicons-screenoptions', 202 );
}
add_action( 'admin_menu', 'mm_setting_menu' );

// call script for setting page
function script_set_page(){
    wp_enqueue_style( 'style-set-page', get_theme_file_uri('/inc/setting-page/style-set-page.css'), NULL, microtime());
    wp_enqueue_script( 'js-set-page', get_theme_file_uri('/inc/setting-page/js-set-page.js'), NULL, microtime(), true);
}
add_action('admin_enqueue_scripts', 'script_set_page');

function mm_setting_block(){
    // ### Displaying Settings
    require get_template_directory().'/inc/setting-page/main-set-page.php';
}

/**
 * Shortcode additions.
 */
require get_template_directory() . '/inc/shortcodes.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * widget additions.
 */
require get_template_directory() . '/inc/costum-widget.php';

/**
 * meta box.
 */
require get_template_directory() . '/inc/add-meta-box.php';
?>