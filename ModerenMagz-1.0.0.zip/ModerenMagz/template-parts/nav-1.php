<!-- TITLE BLOG -->
<div class="main-title">
    <h1>
        <a class="main-title-link" href="<?php echo home_url(); ?>">
        <?php echo get_bloginfo('name'); ?>
        </a>
    </h1>
</div>

<!-- Navbar -->
<div class="navbar"> 
    <nav class="navbar-h">
        <!-- Icon burger -->
        <div id="menu-icon" class="center-icon">
            <svg class="icon-menu" viewBox="0 0 64 35">
                <g>
                    <polygon points="49 14 15 14 0 14 0 21 15 21 49 21 64 21 64 14 49 14" />
                    <polygon points="49 28 15 28 7 28 14 35 15 35 49 35 50 35 57 28 49 28" />
                    <polygon points="50 0 49 0 15 0 14 0 7 7 15 7 49 7 57 7 50 0" />
                </g>
            </svg>
        </div>
        <?php
            // Nav WP
            wp_nav_menu( 
                array(
                    'theme_location' => 'primary',
                    'container' => false,
                    'menu_class' => 'container',
                ) 
            );
        ?>
    </nav>

    <!-- Display on mobile -->
    <div id="slideout-menu">
    <?php
    // Nav WP mobile
    wp_nav_menu( 
        array(
            'theme_location' => 'primary',
            'container' => false,
        ) 
    );
    ?>
    </div>
</div>