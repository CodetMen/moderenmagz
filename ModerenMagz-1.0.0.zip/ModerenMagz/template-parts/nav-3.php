<!-- Navbar -->
<div class="navbar">
    <div class="navbar-h-3">
        <div id="myNav" class="overlay">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <div class="overlay-content">
                <?php
                // Nav WP
                    wp_nav_menu( 
                        array(
                            'theme_location' => 'primary',
                            'container' => false,
                            'menu_class' => '',
                        ) 
                    );
                ?>
            </div>
        </div>
            
        <div class="menu-icon-3" onclick="openNav()">
            <svg class="icon-menu" viewBox="0 0 49 35">
                <g id="Layer_2" data-name="Layer 2">
                    <g id="Layer_1-2" data-name="Layer 1">
                        <rect y="14" width="49" height="7" />
                        <polygon points="35 0 0 0 0 7 42 7 35 0" />
                        <polygon points="42 28 0 28 0 35 35 35 42 28" />
                    </g>
                </g>
            </svg>
        </div>

        <div class="main-title3">
            <!-- TITLE BLOG -->
            <h1>
                <a class="main-title-link" href="<?php echo home_url(); ?>">
                    <?php echo get_bloginfo('name'); ?>
                </a>
            </h1>
        </div>
    </div>
</div>