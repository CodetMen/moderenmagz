<!-- Navbar -->
<div class="navbar"> 
    <nav class="navbar-h-2">
            <div class="main-title2">
                <!-- TITLE BLOG -->
                <h1>
                    <a class="main-title-link" href="<?php echo home_url(); ?>">
                        <?php echo get_bloginfo('name'); ?>
                    </a>
                </h1>
            </div>
            <!-- Icon burger -->
            <div id="menu-icon">
                <svg class="icon-menu" viewBox="0 0 49 35">
                    <g id="Layer_2" data-name="Layer 2">
                        <g id="Layer_1-2" data-name="Layer 1">
                            <rect y="14" width="49" height="7" />
                            <polygon points="35 0 0 0 0 7 42 7 35 0" />
                            <polygon points="42 28 0 28 0 35 35 35 42 28" />
                        </g>
                    </g>
                </svg>
            </div>
            <?php
            // Nav WP
                wp_nav_menu( 
                    array(
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'nav-menus',
                    ) 
                );
            ?>
    </nav>

    <!-- Display on mobile -->
    <div id="slideout-menu">
    <?php
    // Nav WP
    wp_nav_menu( 
        array(
            'theme_location' => 'primary',
            'container' => false,
        ) 
    );
    ?>
    </div>
</div>