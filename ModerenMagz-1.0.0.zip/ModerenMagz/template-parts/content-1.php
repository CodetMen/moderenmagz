<div class="grid-posting">
    <?php 
    $argPosts = array( 'post_type' => 'post', 'posts_per_page' => 8,);
    $blogPosts = new WP_Query($argPosts);

    while($blogPosts->have_posts()):
        $blogPosts->the_post();
    ?>
    <div class="thumbnail">
        <div class="p-author">
            <b class="p-caption">
                <?php echo substr(get_the_author(), 0, 1); ?>
            </b>
            &nbsp-&nbsp<?php the_author(); ?>
        </div>
        
        <?php if(has_post_thumbnail()):?>
            <img class="img-responsive" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="<?php the_title(); ?>"/>
        <?php else: ?>
            <img class="img-responsive" src="<?php echo get_template_directory_uri().'/img/default_1.jpg'; ?>" alt="<?php the_title(); ?>"/>
        <?php endif; ?>
        
        <div class="p-tag">
            <?php echo the_category(); ?>
        </div>
        <div class="p-detail">
            <a href="<?php the_permalink(); ?>" class="detail-link2">
                <h3><?php echo wp_trim_words( get_the_title(), 6); ?></h3>
            </a>
            <p><?php echo wp_trim_words( get_the_content(), 21); ?></p>
        </div>
        <a href="<?php the_permalink(); ?>" class="read-link">Read...</a>
    </div>
    <?php 
    endwhile;
    wp_reset_query();
    ?>
</div>