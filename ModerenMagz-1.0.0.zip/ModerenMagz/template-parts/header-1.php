<header class="front-head-1" id="header-1">
    <div class="container">

        <div id="carousel">
            <ul class="flip-items">
                <?php 
                $argPost_head = array(
                    'post_type' => 'post',
                    'post_per_header' => 5,
                );

                $post_head = new WP_Query($argPost_head);

                while($post_head->have_posts()):
                    $post_head->the_post();
                ?>
                <li data-flip-title="<?php the_title(); ?>">
                    <div class="img-slide-1">
                        <?php if (has_post_thumbnail()): ?>
                            <img class="slide-img-1" src="<?php the_post_thumbnail_url(get_the_ID()); ?>" alt="<?php the_title(); ?>">
                        <?php else: ?>
                            <img class="slide-img-1" src="<?php echo get_template_directory_uri().'/img/default_1.jpg'; ?>" alt="<?php the_title(); ?>"/>
                        <?php endif; ?>
                        
                        <div class="caption-slide-1">
                            <a class="link-slide-1" href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3></h3></a>
                        </div>
                    </div>
                </li>
                <?php 
                endwhile;
                wp_reset_query(); ?>
            </ul>
        </div>

    </div>
</header>