<div class="grid-posting">
    <?php 
        while(have_posts()):
        the_post();
    ?>
    <div class="imaging-thumbnail">
        <?php if(has_post_thumbnail()):?>
            <img class="img-responsive" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="<?php echo the_title(); ?>"/>
        <?php else: ?>
            <img class="img-responsive" src="<?php echo get_template_directory_uri().'/img/default_3.jpg'; ?>" alt="<?php echo the_title(); ?>"/>
        <?php endif; ?>
        <div class="overlay-detail">
            <a href="<?php the_permalink(); ?>" class="detail-link">
                <h3>
                    <?php echo wp_trim_words( get_the_title(), 6); ?>
                </h3>
            </a>
            <p><?php echo wp_trim_words( get_the_content(), 32); ?></p>
            <a href="<?php the_permalink(); ?>" class="read-link">Read...</a>
        </div>
    </div>
    <?php 
    endwhile;
    wp_reset_query(); 
    ?>
</div>

<div class="pagination">
    <?php echo paginate_links(); ?>
</div>