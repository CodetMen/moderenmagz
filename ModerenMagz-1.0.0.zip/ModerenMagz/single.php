<?php
require get_template_directory().'/inc/ModerenMagz.php';

get_header(); 
?>    
<div class="content">
    <div class="container">
        <!-- Content -->
        <div class="col-m-8">
            <div class="single-content">
                <?php
                while(have_posts()):
                    the_post();
                ?>
                <div class="nav-inherit">
                    <?php 
                    $breadcrumb = new ModerenMagz();
                    $breadcrumb->the_breadcrumb();
                    ?>
                </div>
                <div class="single-title">
                    <h1><?php echo the_title(); ?></h1>
                </div>
                <div class="detail-post">
                    <svg class="man-vector" viewBox="0 0 5.5 7.41">
                        <g id="Layer_1-2" data-name="Layer 1">
                            <path
                                d="M3.62,3.38H3.47A1.77,1.77,0,1,0,2,3.38H1.88A1.88,1.88,0,0,0,0,5.25V7.41H5.5V5.25A1.88,1.88,0,0,0,3.62,3.38Z" />
                        </g>
                    </svg>
                    <?php echo get_the_author(); ?>
                    <svg class="cal-vector" viewBox="0 0 10.5 7.98">
                        <g>
                            <path
                                d="M9.3.35v.4a.2.2,0,0,1-.2.2H8.65a.2.2,0,0,1-.2-.2V.35H8.1v.4a.2.2,0,0,1-.2.2H7.44a.2.2,0,0,1-.2-.2V.35H6.89v.4a.2.2,0,0,1-.2.2H6.23A.2.2,0,0,1,6,.75V.35H5.68v.4a.2.2,0,0,1-.2.2H5a.2.2,0,0,1-.2-.2V.35H4.47v.4a.2.2,0,0,1-.2.2H3.82a.2.2,0,0,1-.2-.2V.35H3.26v.4a.2.2,0,0,1-.2.2H2.61a.2.2,0,0,1-.2-.2V.35H2.05v.4a.2.2,0,0,1-.2.2H1.4a.2.2,0,0,1-.2-.2V.35H0V8H10.5V.35ZM1.45,7H.5v-1h1Zm0-1.16H.5V4.9h1Zm0-1.16H.5v-1h1Zm0-1.15H.5v-1h1Zm0-1.16H.5V1.43h1ZM2.67,7H1.72v-1h1Zm0-1.16H1.72V4.9h1Zm0-1.16H1.72v-1h1Zm0-1.15H1.72v-1h1Zm0-1.16H1.72V1.43h1ZM3.9,7h-1v-1h1Zm0-1.16h-1V4.9h1Zm0-1.16h-1v-1h1Zm0-1.15h-1v-1h1Zm0-1.16h-1V1.43h1ZM5.12,5.85h-1V4.9h1Zm0-1.16h-1v-1h1Zm0-1.15h-1v-1h1Zm0-1.16h-1V1.43h1ZM6.34,5.85h-1V4.9h1Zm0-1.16h-1v-1h1Zm0-1.15h-1v-1h1Zm0-1.16h-1V1.43h1ZM7.56,5.85H6.61V4.9h.95Zm0-1.16H6.61v-1h.95Zm0-1.15H6.61v-1h.95Zm0-1.16H6.61V1.43h.95ZM8.79,5.85h-1V4.9h1Zm0-1.16h-1v-1h1Zm0-1.15h-1v-1h1Zm0-1.16h-1V1.43h1ZM10,5.85H9.06V4.9H10Zm0-1.16H9.06v-1H10Zm0-1.15H9.06v-1H10Zm0-1.16H9.06V1.43H10Z" />
                            <rect x="1.4" width="0.45" height="0.75" />
                            <rect x="2.61" width="0.45" height="0.75" />
                            <rect x="3.82" width="0.45" height="0.75" />
                            <rect x="5.03" width="0.45" height="0.75" />
                            <rect x="6.23" width="0.46" height="0.75" />
                            <rect x="7.44" width="0.46" height="0.75" />
                            <rect x="8.65" width="0.45" height="0.75" />
                        </g>
                    </svg>
                    <?php echo get_the_date(); ?>
                </div>
                <div class="single-img">
                    <span class="box-img-lf-top"></span>
                    <span class="box-img-lf-btm"></span>
                    <span class="box-img-rg-top"></span>
                    <span class="box-img-rg-btm"></span>
                    <?php if(has_post_thumbnail()){ ?>
                        <img class="img-responsive" src="<?php echo the_post_thumbnail_url(get_the_ID()); ?>" alt="<?php echo the_title(); ?>"/>
                    <?php } else { ?>
                        <img class="img-responsive" src="<?php echo get_template_directory_uri().'/img/default_3.jpg'; ?>" alt="<?php echo the_title(); ?>"/>    
                    <?php } ?>
                </div>
                <div class="single-detail">
                    <p>
                        <?php the_content(); ?>
                    </p>
                    <div class="single-tags">
                        <?php echo the_category(); ?>
                    </div>
                </div>
                

                <div class="comment-single">
                <?php 
                    // If comments are open or we have at least one comment, load up the comment template.
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                ?>
                </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="col-m-4">
            <?php get_sidebar('main'); ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>