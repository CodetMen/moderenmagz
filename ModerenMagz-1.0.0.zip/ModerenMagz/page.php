<?php 
require get_template_directory().'/inc/ModerenMagz.php';
get_header();
?>
    <div class="content">
        <div class="container">
            <!-- Content -->    
            <div class="col-m-8">
                <div class="single-content">
                    <?php
                    if (have_posts()):
                        the_post();
                    ?>
                    <div class="nav-inherit">
                        <?php
                        $breadcrumb = new ModerenMagz();
                        $breadcrumb->the_breadcrumb();
                        ?>
                    </div>
                    <div class="single-title">
                        <h1><?php the_title(); ?></h1>
                    </div>
                    <div class="single-img">
                        <span class="box-img-lf-top"></span>
                        <span class="box-img-lf-btm"></span>
                        <span class="box-img-rg-top"></span>
                        <span class="box-img-rg-btm"></span>
                        <?php if (has_post_thumbnail()): ?>
                            <img class="img-responsive" src="<?php echo get_the_post_thumbnail_url(get_the_ID());?>" alt="<?php the_title(); ?>"/>
                        <?php else: ?>
                            <img class="img-responsive" src="<?php echo get_template_directory_uri().'/img/default_3.jpg';?>" alt="<?php the_title(); ?>"/>
                        <?php endif; ?>
                    </div>
                    <div class="single-detail single-detail-space">
                        <?php the_content(); ?>
                    </div>
                    <?php
                    endif;
                    wp_reset_query();
                    ?>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="col-m-4">
                <?php get_sidebar('main'); ?>
            </div>
        </div>
    </div>
                
<?php get_footer(); ?>